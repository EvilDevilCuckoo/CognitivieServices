﻿using Microsoft.ProjectOxford.Emotion.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CucoDelDiablo.CognitiveServices.UI.Manager
{
    public  class AugmentedScores : Scores
    {
        public AugmentedScores()
        {
          
        }
        #region
        public float Snark { get; set; }
        public float Frustrated { get; set; }
        public float Pain { get; set; }
        #endregion
    }
}
