﻿using Microsoft.ProjectOxford.Emotion.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CucoDelDiablo.CognitiveServices.UI.Manager
{
    public class AugmentedEmotion : Emotion
    {
        public AugmentedEmotion() {
            
        }

        #region properties
        public AugmentedScores SuperScores { get; set; }
        #endregion


    }
}
