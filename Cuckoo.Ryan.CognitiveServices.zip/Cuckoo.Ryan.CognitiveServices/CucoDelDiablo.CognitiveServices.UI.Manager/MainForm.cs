﻿using CucoDelDiablo.CognitiveServices.UI.Manager.Forms;
using Microsoft.ProjectOxford.Emotion;
using Microsoft.ProjectOxford.Emotion.Contract;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Media.Imaging;

namespace CucoDelDiablo.CognitiveServices.UI.Manager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void keyManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KeyManager Form = new Forms.KeyManager();
            Form.ShowDialog();
        }

        private async void linkLabelProcess_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            Emotion[] EmotionList = await DetectEmotion();
                if(EmotionList != null && EmotionList.Length > 0)
            {
                foreach (Emotion emotion in EmotionList)
                {
                  
                    textBoxResults.Text += String.Format(CultureInfo.CurrentCulture, "Left:{0} Width:{1} Height:{2} Top:{3}\r\n", emotion.FaceRectangle.Left, emotion.FaceRectangle.Width, emotion.FaceRectangle.Height, emotion.FaceRectangle.Top);
                    textBoxResults.Text += String.Format(CultureInfo.CurrentCulture, "{0} - {1}\r\n", "Anger", emotion.Scores.Anger);
                    textBoxResults.Text += String.Format(CultureInfo.CurrentCulture, "{0} - {1}\r\n", "Contempt", emotion.Scores.Contempt);
                    textBoxResults.Text += String.Format(CultureInfo.CurrentCulture, "{0} - {1}\r\n", "Disgust", emotion.Scores.Disgust);
                    textBoxResults.Text += String.Format(CultureInfo.CurrentCulture, "{0} - {1}\r\n", "Fear", emotion.Scores.Fear);
                    textBoxResults.Text += String.Format(CultureInfo.CurrentCulture, "{0} - {1}\r\n", "Happiness", emotion.Scores.Happiness);
                    textBoxResults.Text += String.Format(CultureInfo.CurrentCulture, "{0} - {1}\r\n", "Neutral", emotion.Scores.Neutral);
                    textBoxResults.Text += String.Format(CultureInfo.CurrentCulture, "{0} - {1}\r\n", "Sadness", emotion.Scores.Sadness);
                    textBoxResults.Text += String.Format(CultureInfo.CurrentCulture, "{0} - {1}\r\n", "Surprise", emotion.Scores.Surprise);
                    textBoxResults.Text += "------------------------------------------\r\n\r\n";
                }
            }
            else
            {
                textBoxResults.Text = "Unable to detect emotions";
            }
           

        }
                
        private async Task<Emotion[]> DetectEmotion()
        {
            EmotionServiceClient FaceClient = new EmotionServiceClient(API.GlobalItems.SubscriptionKey);
            Emotion[] ResultSet = await FaceClient.RecognizeAsync(listBox1.SelectedItem.ToString());

            return ResultSet;
        }


        private String WriteEmotionDetails(Emotion[] emotions)
        {
            StringBuilder Builder = new StringBuilder();
            foreach (Emotion emotion in emotions)
            {
                var stringPropertyNamesAndValues = emotion.GetType()
.GetProperties()
.Where(pi => pi.PropertyType == typeof(string) && pi.GetGetMethod() != null)
.Select(pi => new
{
    Name = pi.Name,
    Value = pi.GetGetMethod().Invoke(emotion, null)
});
                foreach (var pair in stringPropertyNamesAndValues)
                {
                    Builder.AppendFormat(CultureInfo.CurrentCulture, "{0}: Value: {1}\r\n ", pair.Name, pair.Value);           
                }
            }
            return Builder.ToString();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            API.GlobalItems.SubscriptionKey = IsolatedStorageManager.GetSubscriptionKeyFromIsolatedStorage();
        }

        private void textBoxImageUri_TextChanged(object sender, EventArgs e)
        {
            linkLabelAdd.Enabled = textBoxImageUri.Text.Length > 5;
           // linkLabelProcess.Enabled = textBoxImageUri.Text.Length > 5;
        }

        private void linkLabelAdd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            listBox1.Items.Add(textBoxImageUri.Text);
            textBoxImageUri.Text = String.Empty;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
                linkLabelProcess.Enabled = listBox1.SelectedItem != null;
          
        }
    }
}
