﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CucoDelDiablo.CognitiveServices.UI.Manager.Forms
{
    public partial class KeyManager : Form
    {

        private readonly string _isolatedStorageSubscriptionKeyFileName = "Subscription.txt";
        private readonly String _defaultSubscriptionKeyPromptMessage = "Enter Subscription Key";
        public KeyManager()
        {
            InitializeComponent();
            buttonSave.Enabled = false;
        
        }


        private void buttonSave_Click(object sender, EventArgs e)
        {
            SaveSubscriptionKeyToIsolatedStorage(textBox1.Text);

            buttonSave.Enabled = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            buttonSave.Enabled = textBox1.Text.Length > 10;
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region methods
       

        /// <summary>
        /// Saves the subscription key to isolated storage.
        /// </summary>
        /// <param name="subscriptionKey">The subscription key.</param>
        private void SaveSubscriptionKeyToIsolatedStorage(string subscriptionKey)
        {
            using (IsolatedStorageFile isoStore = IsolatedStorageFile.GetStore(IsolatedStorageScope.User | IsolatedStorageScope.Assembly, null, null))
            {
                using (var oStream = new IsolatedStorageFileStream(_isolatedStorageSubscriptionKeyFileName, FileMode.Create, isoStore))
                {
                    using (var writer = new StreamWriter(oStream))
                    {
                        writer.WriteLine(subscriptionKey);
                    }
                }
            }
        }

        #endregion

        private void KeyManager_Load(object sender, EventArgs e)
        {
            API.GlobalItems.SubscriptionKey = IsolatedStorageManager.GetSubscriptionKeyFromIsolatedStorage();
            if (!String.IsNullOrWhiteSpace(API.GlobalItems.SubscriptionKey))
            {
                textBox1.Text = API.GlobalItems.SubscriptionKey;
            }
        }
    }
}
