﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CucoDelDiablo.CognitiveServices.API
{
    public static class GlobalItems
    {
        #region properties
        /// <summary>
        /// Gets or sets the SubscriptionKey property.
        /// </summary>
        public static String SubscriptionKey { get; set; }
        #endregion
    }
}
